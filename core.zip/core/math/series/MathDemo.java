package com.core.math.series;

import java.lang.*;

public class MathDemo {

   public static void main(String[] args) {

      // get two double numbers
      double x = 125.9;
      double y = 0.4873;
   
      int xx = 10;
      // call ceal for these these numbers
      System.out.println("########Math ceil() Ouputs############\n");
      System.out.println("Math.ceil(" + x + ")=" + Math.ceil(x));
      System.out.println("Math.ceil(" + y + ")=" + Math.ceil(y));
      System.out.println("Math.ceil(-0.65)=" + Math.ceil(-0.65));
      
   // call floor and print the result
      System.out.println("\n##########Math floor() Ouputs############\n");
      System.out.println("Math.floor(" + x + ")=" + Math.floor(x));
      System.out.println("Math.floor(" + y + ")=" + Math.floor(y));
      System.out.println("Math.floor(0)=" + Math.floor(0));
      
      // get two random double numbers
       x = Math.random();
       y = Math.random();
   
      // print the numbers and print the higher one
      System.out.println("\n##########Math random() Ouputs############\n");
      System.out.println("Random number 1:" + x);
      System.out.println("Random number 2:" + y);
      System.out.println("Highest number:" + Math.max(x, y));
      
   }
}
