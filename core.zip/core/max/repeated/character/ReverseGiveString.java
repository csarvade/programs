package com.core.max.repeated.character;

class ReverseGiveString {
public void getReversedString(String input){
	byte[] strInputArr = input.getBytes();
	byte[] result = new byte[strInputArr.length];
	
	for(int i=0; i<strInputArr.length;i++){
		result[i] = strInputArr[strInputArr.length-i-1];
		
	}
	System.out.println("reversed string is:"+new String(result));
	
}
public static void main(String []args){
	ReverseGiveString rgs = new ReverseGiveString();
	rgs.getReversedString("I Live in India");
}
}
