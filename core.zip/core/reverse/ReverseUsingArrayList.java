package com.core.reverse;

import java.lang.*;
import java.io.*;
import java.util.*;

public class ReverseUsingArrayList {

	public static void main(String[] args) {
		String input = "GeeksNo";
		System.out.print("Before reversing Input String using ArrayList is="+input+"\n");
		char[] charArray = input.toCharArray();
		List<Character> list = new ArrayList<Character>();

		for (char c : charArray)
			list.add(c);

		Collections.reverse(list);
		ListIterator<Character> li = list.listIterator();
		System.out.print("After Reversing String Using ArrayList is = ");
		while (li.hasNext())
			System.out.print(li.next());
	}
}
