package com.core.swap;

public class SwapUsingOnlyTwoVariables {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int x = 10;
		int y = 20;
		
		System.out.println("Swapping Two number without Temporary Variable Usage:\n");
		System.out.println("*****************************************************\n");
		System.out.println("Before Swapping Two numbers value:\n X="+x+" & Y="+y);
		x = x + y;
		y = x - y;
		x = x - y;
		System.out.println("After Swapping Two numbers value:\n X="+x+" & Y="+y);
		
	}

}
