package com.core.demo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

class MyClass{





public  HashMap<String,Integer> wordCount(String []str){
          HashMap<String,Integer> hm = new HashMap<String,Integer>();
		  
		  for( String s : str){
		   
		   if(hm.containsKey(s)){
		   hm.put(s,hm.get(s)+1);
		   }else{
		   hm.put(s,1);
		   }
		  }

return hm;
}
public List<Entry<String,Integer>> getSorted(HashMap<String,Integer> hm){
        Set<Entry<String,Integer>> s = hm.entrySet();
		
		List<Entry<String,Integer>> list = new ArrayList<Entry<String,Integer>>(s);
		
		
		Collections.sort(list, new Comparator<Map.Entry<String, Integer>>(){
		
@Override
public int compare(Map.Entry<String,Integer> ob1, Map.Entry<String, Integer>  ob2){

 return ((Entry<String, Integer>) ob2).getValue().compareTo(((Entry<String, Integer>) ob1).getValue());
}});
	return list;	
}

public static void main(String[]args){
 String [] str = {"apple", "box","apple", "apple","melon","box"}; 
MyClass mc = new MyClass();
HashMap<String, Integer> hm =mc.wordCount(str);
System.out.println(String.valueOf( mc.getSorted(hm)));
}
}
