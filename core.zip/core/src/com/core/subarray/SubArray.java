package com.core.subarray;

public class SubArray {
	public static void findSubarraysWithSum(int[] arr, int targetSum) {
	     int n = arr.length;

	        // Iterate over all possible starting points
	        for (int start = 0; start < n; start++) {
	            int currentSum = 0;

	            // Iterate over all possible ending points from the start
	            for (int end = start; end < n; end++) {
	                // Add the current element to the current sum
	                currentSum += arr[end];

	                // If current sum matches the target, print the subarray
	                if (currentSum == targetSum) {
	                    System.out.print("Subarray with sum " + targetSum + ": ");
	                    for (int i = start; i <= end; i++) {
	                        System.out.print(arr[i] + " ");
	                    }
	                    System.out.println(); // New line for each subarray
	                }
	            }
	        }
	    }

	    public static void main(String[] args) {
	        // Example array and target sum
	     int arr[] = {42, 15, 12, 8, 6, 32};
	        int targetSum = 26;

	        // Calling the function to find subarrays with the given sum
	        System.out.println("Subarrays with sum " + targetSum + ":");
	        findSubarraysWithSum(arr, targetSum);
	    }
		
}
