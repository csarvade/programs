package com.core.transpose.matrix;

public class MatrixTranspose {

    public static void main(String[] args) {
        // Example matrix
        int[][] matrix = {
            {1, 2, 3},
            {4, 5, 6},
            {7, 8, 9}
        };
        
        // Find and print the transpose of the matrix
        int[][] transposedMatrix = transposeMatrix(matrix);
        printMatrix(transposedMatrix);
    }
    
    // Function to transpose a matrix
    public static int[][] transposeMatrix(int[][] matrix) {
        int rows = matrix.length;         // Number of rows in the original matrix
        int cols = matrix[0].length;      // Number of columns in the original matrix
        
        int[][] transposedMatrix = new int[cols][rows]; // Transposed matrix of size cols x rows
        
        // Transpose the matrix by swapping rows and columns
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                transposedMatrix[j][i] = matrix[i][j];
            }
        }
        
        return transposedMatrix;
    }
    
    // Function to print the matrix
    public static void printMatrix(int[][] matrix) {
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println();
        }
    }
}
