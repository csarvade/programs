package com.core.stream.api;

import java.util.*;
import java.util.function.Function;
import java.util.stream.*;

public class FirstNonRepeatedCharacter {

    public static char findFirstNonRepeatedChar(String str) {
        // Convert each character to lowercase and count occurrences using streams
        Map<Character, Long> charCountMap = str.chars()
                                               .mapToObj(c -> (char) Character.toLowerCase(c))  // Convert to lowercase
                                               .collect(Collectors.groupingBy(Function.identity(), LinkedHashMap::new, Collectors.counting()));

        // Find the first character with a count of 1 (non-repeated)
        return charCountMap.entrySet()
                           .stream()
                           .filter(entry -> entry.getValue() == 1)
                           .map(Map.Entry::getKey)
                           .skip(1)
                           .findFirst()
                           .orElse('\0'); // Return '\0' if no non-repeated character is found
    }

    public static void main(String[] args) {
        String input = "aAbccDe";
        char result = findFirstNonRepeatedChar(input);

        if (result != '\0') {
            System.out.println("The first non-repeated character is: " + result);
        } else {
            System.out.println("There is no non-repeated character.");
        }
    }
}

