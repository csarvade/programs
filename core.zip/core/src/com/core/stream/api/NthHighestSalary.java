package com.core.stream.api;

/******************************************************************************

Online Java Compiler.
Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.*;

public class NthHighestSalary {
public static void main(String[] args) {
Map<String, Integer> map = new HashMap<>();
map.put("vivek", 100);
map.put("kiran", 150);
map.put("arun", 140);
map.put("varun", 190);

int n = 3; // Change this value to get the N-th highest salary

Optional<Map.Entry<String, Integer>> nthSalaryEntry = findNthHighestSalary(map, n);

if (nthSalaryEntry.isPresent()) {
System.out.println("The " + n + "-th highest salary is: " + nthSalaryEntry.get().getValue() + 
   " (Employee: " + nthSalaryEntry.get().getKey() + ")");
} else {
System.out.println("Invalid input! N is out of range.");
}
}

public static Optional<Map.Entry<String, Integer>> findNthHighestSalary(Map<String, Integer> map, int n) {
return map.entrySet()
		.stream()
		.sorted(Map.Entry.<String, Integer>comparingByValue(Comparator.reverseOrder())) // Sort by value descending
        .distinct() // Remove duplicate salaries
        .skip(n - 1) // Skip first (n-1) elements
        .findFirst(); // Get the nth element
}
}


