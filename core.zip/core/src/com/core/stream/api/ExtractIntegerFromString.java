package com.core.stream.api;

import java.util.*;
import java.util.stream.*;

public class ExtractIntegerFromString {

    public static int extractFirstInteger(String str) {
        // Use stream to extract numbers from the string
        return str.chars()  // Convert the string to an IntStream of character codes
                  .filter(Character::isDigit) // Keep only the digit characters
                  .mapToObj(c -> (char) c)  // Convert the int stream to a stream of characters
                  .map(String::valueOf)  // Convert the characters to string
                  .collect(Collectors.joining())  // Join the characters into a single string
                  .chars()  // Convert the string of digits back to an IntStream
                  .map(c -> c - '0')  // Convert characters to their respective integer values
                  .reduce(0, (num, digit) -> num * 10 + digit);  // Convert the string of digits to an integer
    }

    public static void main(String[] args) {
        String input = "abc123def456";
        int result = extractFirstInteger(input);
        System.out.println("First integer found: " + result);  // Output will be 123
    }
}

