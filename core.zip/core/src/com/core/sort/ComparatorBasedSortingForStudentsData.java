package com.core.sort;

import java.util.*;
import java.lang.*;
import java.io.*;

public class ComparatorBasedSortingForStudentsData {

	// Java program to demonstrate working of Comparator
	// interface and Collections.sort() to sort according
	// to user defined criteria.

	int rollno;
	String name, address;

	// Constructor
	public ComparatorBasedSortingForStudentsData(int rollno, String name, String address) {
		this.rollno = rollno;
		this.name = name;
		this.address = address;
	}

	// Used to print student details in main()
	public String toString() {
		return this.rollno + " " + this.name + " " + this.address;
	}
}

class Sortbyroll implements Comparator<ComparatorBasedSortingForStudentsData> {
	// Used for sorting in ascending order of
	// roll number
	public int compare(ComparatorBasedSortingForStudentsData a, ComparatorBasedSortingForStudentsData b) {
		return a.rollno - b.rollno;
	}
}

// Driver class
class Main {
	public static void main(String[] args) {
		ArrayList<ComparatorBasedSortingForStudentsData> ar = new ArrayList<ComparatorBasedSortingForStudentsData>();
		ar.add(new ComparatorBasedSortingForStudentsData(111, "bbbb", "london"));
		ar.add(new ComparatorBasedSortingForStudentsData(131, "aaaa", "nyc"));
		ar.add(new ComparatorBasedSortingForStudentsData(121, "cccc", "jaipur"));

		System.out.println("Unsorted");
		for (int i = 0; i < ar.size(); i++)
			System.out.println(ar.get(i));

		Collections.sort(ar, new Sortbyroll());

		System.out.println("\nSorted by rollno");
		for (int i = 0; i < ar.size(); i++)
			System.out.println(ar.get(i));
	}
}
