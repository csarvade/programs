package com.core.sort;

/**
 * Complexity => summation of O(i) here i ranges b/w 0 to N = 1+2+3+...+(N-1) =
 * O(n * n)
 * 
 * @author BHARATI
 *
 */
public class BubbleSort {
	public void bubbleSort(int ar[]) {

		for (int i = (ar.length - 1); i >= 0; i--) {
			for (int j = 1; j <= i; j++) {
				if (ar[j - 1] > ar[j]) { // If ((N-1) > N) ?
					int temp = ar[j - 1]; // sorting logic starts here.
					ar[j - 1] = ar[j];
					ar[j] = temp; // sorting logic ends here.
				}

			}

		}

	}

	public static void main(String args[]) {
		BubbleSort bs = new BubbleSort();
		int[] ar = { 2, 10, 5, 3, 6, 4 };
		bs.bubbleSort(ar);
		System.out.println("Bubble Sort List:-");
		for (int k = 0; k <= ar.length - 1; k++)
			System.out.println(ar[k] + " "); // ascending order.
	}
}
