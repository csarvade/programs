package com.core.max.salary.stream;

import java.util.*;
import java.util.stream.*;

public class HighSalaryProgram {
    public static void main(String[] args) {
        // Sample list of employees
        List<Employee> employees = Arrays.asList(
            new Employee("John", 90000),
            new Employee("Alice", 120000),
            new Employee("Bob", 50000),
            new Employee("Diana", 110000),
            new Employee("Charlie", 80000)
        );

        // Find the employee with the highest salary using Stream
        Optional<Employee> highestPaidEmployee = employees.stream()
            .max(Comparator.comparingDouble(Employee::getSalary));

        // If there is a highest paid employee, filter all employees with the highest salary
        highestPaidEmployee.ifPresent(highest -> {
            double maxSalary = highest.getSalary();
            List<Employee> highSalaryEmployees = employees.stream()
                .filter(employee -> employee.getSalary() == maxSalary)
                .collect(Collectors.toList());

            // Printing employees with the highest salary
            System.out.println("Employees with the highest salary (" + maxSalary + "):");
            highSalaryEmployees.forEach(System.out::println);
        });
    }
}

