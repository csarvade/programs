package com.core.math.series;

import java.util.Scanner;

public class FibonacciSeries {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int n1=0;
        int n2 = 1;
        int n3 = 0;
		System.out.println("Enter Fibonacci Series Limit:\n");
		Scanner sc = new Scanner(System.in);
		int fiboSeriesLimit = sc.nextInt();
		System.out.println("The Fibonacci Series For Given Limit "+fiboSeriesLimit+" is:-\n");
		for(int i=0; i<fiboSeriesLimit; i++){
			n3 = n1 + n2;
			n1= n2;
			n2 = n3;
			System.out.println(n3);
		}
		
	}

}
