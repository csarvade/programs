package com.core.prime;

public class PrimeNumbersFrom1To100 {
	public void getPrimeNumber(int n){
		System.out.println("Prime Numbers:\n");
		for(int i=1; i<n; i++){
			boolean flag = true;
			for(int j=2; j<i;j++){
				if(i % j == 0){
					flag = false;
					break;
				}
			}
			if(flag){
				System.out.println(i);
			}
		}
		
	}

	public static void main(String args[]){
		PrimeNumbersFrom1To100 OneToHundread = new PrimeNumbersFrom1To100();
		OneToHundread.getPrimeNumber(2000);
	}
}
