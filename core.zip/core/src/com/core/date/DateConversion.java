package com.core.date;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateConversion {

	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		System.out.println("################################ HH:MM:SS to Date Conversion##################################");
		String myDateString = "00:30:00";
		
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
		Date date = sdf.parse(myDateString);
		System.out.println("Date is:"+date);
		System.out.println("################################ Date to HH:MM:SS conversion##################################");
		SimpleDateFormat sdf1 = new SimpleDateFormat("HH:mm");
		java.util.Date date1 = date;
		String string = sdf.format(date1);
		System.out.println(string);
		
		
		System.out.println("################################ HH:MM:SS Difference Time Calculation##################################");
		String dateStart = "18/03/18 00:30:00";
		String dateStop = "18/03/19 01:00:00";
		

		// Custom date format
		SimpleDateFormat sdf2 = new SimpleDateFormat("yy/MM/dd HH:mm:ss");  

		Date d1 = null;
		Date d2 = null;
		try {
		    d1 = sdf2.parse(dateStart);
		    d2 = sdf2.parse(dateStop);
		} catch (ParseException e) {
		    e.printStackTrace();
		}    

		// Get msec from each, and subtract.
		long diffTimes = d2.getTime() - d1.getTime();
		long diffSeconds = diffTimes / 1000;         
		long diffMinutes = diffTimes / (60 * 1000);         
		long diffHours = diffTimes / (60 * 60 * 1000);   
		System.out.println("\nDifference In Two Times = d2.getTime() - d1.getTime()");
		System.out.println("=>"+diffTimes+"="+d2.getTime()+"-"+d1.getTime());
		System.out.println("Time in seconds: " + diffSeconds + " seconds.");         
		System.out.println("Time in minutes: " + diffMinutes + " minutes.");         
		System.out.println("Time in hours: " + diffHours + " hours."); 

	}

}
