package com.core.leetcode;

import java.util.HashSet;

/*3. Contains Duplicate
 * Given an integer array nums, return true if any value appears at
 * least twice, and false if all elements are distinct.
 */
public class ContainsDups {
public boolean getDups(int []nums) {
	HashSet<Integer> hs = new HashSet<>();
	for(int num : nums) {
		if(hs.contains(num)) {
			return true;
		}
		hs.add(num);
	}
	return false;
}
public static void main(String []args) {
	ContainsDups cd = new  ContainsDups();
    int [] nums = {1,3,2,1,2,5};
    System.out.println(cd.getDups(nums));
}
}
