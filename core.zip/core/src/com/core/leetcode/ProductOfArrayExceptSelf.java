package com.core.leetcode;

import java.util.Arrays;

/*4. Product of Array Except Self (prefix or suffix mode)
 * Given an integer array nums, return an array result 
 * such that result[i] is the product of all elements except nums[i].
 */
public class ProductOfArrayExceptSelf {
public int[] getProductOfArrayExceptSelfIndex(int[]nums) {
	int []result= new int[nums.length];
	//Compute prefix product directly in result array
	result[0] = 1;
	for(int i=1;i<nums.length-1;i++) {
		result[i] = result[i-1] * nums[i-1];
	}
	//Compute suffix product and multiply directly with result array
	int suffix = 1;
	for(int i= nums.length-1;i<=0;i--) {
		result[i]*= suffix;
		suffix*= nums[i]; //update suffix product. 
	}
	return result;
}
public static void main(String []args) {
	ProductOfArrayExceptSelf poaes = new ProductOfArrayExceptSelf();
	int [] nums = {2,4,2,3,6,8,2,39,23,10};
	System.out.println("Product of Array Except Self Index:"+Arrays.toString(poaes.getProductOfArrayExceptSelfIndex(nums)));
}
}
