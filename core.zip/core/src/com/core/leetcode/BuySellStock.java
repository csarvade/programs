package com.core.leetcode;
/*
 * 2. Best Time to Buy and Sell Stock
 * You are given an array prices[], where prices[i] is the stock price on the i-th day.
 * Find the maximum profit you can achieve by buying and selling one stock.
 */
public class BuySellStock {
	public int maxProfit(int[]prices) {
		int minProfit =0;
		int maxProfit =0;
		for(int price: prices) {
			if(price<minProfit) {   //step1 price<minProfit
				minProfit = price;
			}else {
				maxProfit = Math.max(maxProfit, price-minProfit); //step 2 Max of maxProfit, (price-minProfit)
			}
		}
		return maxProfit;	
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int [] prices = {2,10,3,9,2,6,6,3,4,5};
BuySellStock bss = new BuySellStock();
System.out.println("Right Time To Buy or Sell Stock:"+bss.maxProfit(prices));
	}

}
