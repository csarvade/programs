package com.core.leetcode;

import java.util.Arrays;
import java.util.HashMap;

/*1. Given an array of integers nums and an integer target, 
 * return indices of the two numbers such that they add up to target.
 */
public class TwoSum {
	public int[] twoSum(int[]nums,int target) {
		HashMap<Integer,Integer> hm = new HashMap<>();
		for(int i=0;i<nums.length;i++) {
			int key = target-nums[i]; //step 1
			if(hm.containsKey(key))
				return new int[] {hm.get(key),i};// retun indices  //step2
			hm.put(nums[i],i); //step3
		} 
		
		return new int[] {-1,-1};// retun indices
	}
public static void main(String []args) {
	TwoSum ts = new TwoSum();
	int[]nums = {2,7,11,15,4};
	int target =11;
	System.out.println(Arrays.toString(ts.twoSum(nums, target)));
}
}
