package com.core.datastructure;
import java.util.*;

class Node {
	int data;
	Node next;

	Node(int d) {
		data = d;
		next = null;
	}
}

public class MergedSortedList {
	Node head;

	public void addToList(Node node) {// method to insert node at end of list.
		if (head == null) {
			head = node;
		} else {
			Node temp = head;
			while (temp.next != null) {
				temp = temp.next;
				temp.next = node;
			}
		}
	}// end of addToList(); method

	public void printList() {// print linked list

		Node temp = head;
		while (temp != null) {

			System.out.println(temp.data + "");
			temp = temp.next;
		}
		System.out.println("");

	}

	public static void main(String[] args) {
		MergedSortedList l1 = new MergedSortedList();
		MergedSortedList l2 = new MergedSortedList();

		l1.addToList(new Node(1));
		l1.addToList(new Node(15));
		l1.addToList(new Node(13));

		l2.addToList(new Node(20));
		l2.addToList(new Node(12));
		l2.addToList(new Node(22));

		l1.head = new SortedMerged().sortedMerged(l1.head, l2.head);
		l1.printList();
	}
}

class SortedMerged {
	public Node sortedMerged(Node headA, Node headB) {
		Node dummyNode = new Node(0); // first node to point initial result
										// node.
		Node tail = dummyNode; // to point end node.
		while (true) {

			if (headA == null) {// use node either one for initial value
				tail.next = headB;
				break;
			}
			if (headB == null) {
				tail.next = headA;
				break;
			}

			/* sorting and advancing nodes for next values */
			if (headA.data <= headB.data) {
				tail.next = headA;
				headA = headA.next;
			} else {
				tail.next = headB;
				headB = headB.next;
			}
			tail = tail.next;// incrementing tail.
		}
		return dummyNode.next;

	}

}