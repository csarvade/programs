package com.core.datastructure;

public class StackWithConcurrency implements Runnable{
	int top = 0;
	int max = 1000;
	int min = 0;
	int ar[] = new int[max]; 
	
	boolean push(int n){
		if(top>= max-1){
			System.out.println("stack overflow");
			return false;
		}else{
			ar[++top] = n;
			System.out.println(n+ " pushed to stack");
			return true;
		}
	}
	int pop(){
		if(top<min){
			System.out.println("stack is underflow");
			return 0;
		}else{
			int n = ar[top--];
			System.out.println(n + " Poped from stack");
			return n;
		}
	}

	public static void main(String []args){
		StackWithConcurrency s = new StackWithConcurrency();
		Thread t = new Thread(s);
		t.start();
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		for(int i=0;i<5; i++){
		push(i);
		pop();
		}
		
	}
}
