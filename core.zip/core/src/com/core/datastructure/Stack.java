package com.core.datastructure;

public class Stack {
	int top = 0;
	int max = 1000;
	int min = 0;
	int ar[] = new int[max]; 
	
	boolean push(int n){
		if(top>= max-1){
			System.out.println("stack overflow");
			return false;
		}else{
			ar[++top] = n;
			System.out.println(n+ " pushed to stack");
			return true;
		}
	}
	int pop(){
		if(top<min){
			System.out.println("stack is underflow");
			return 0;
		}else{
			int n = ar[top--];
			return n;
		}
	}

	public static void main(String []args){
		Stack s = new Stack();
		s.push(10);
		s.push(20);
		s.push(30);
		System.out.println(s.pop() + " Poped from stack");
	}
}
