package com.core.monotonic;

import java.util.List;

public class RepeatedChar {
public static void main(String []args) {
	String input = "chetankumarraghuk";
	 List<Character> list = input.toCharArray()
	                        .mapToObject(Character.toLowerCase().Character.(i-> (char)i))
							.entryset()
							.filter(entry->entry.getValue()==c)
	 .skip(3) // Skip the first 3 repeated characters
     .findFirst();

}
}
