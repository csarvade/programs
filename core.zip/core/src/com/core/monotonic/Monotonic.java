package com.core.monotonic;

public class Monotonic {
	public static boolean getMonotonic(int[] arr) {
		int n = arr.length - 1;
		boolean mono = false;
		boolean monoTwo = false;
		for (int i = 0; i < n; i++) {
			if (arr[i] < arr[i + 1]) {
				mono = true;
				continue;
			} else if (arr[i] > arr[i + 1]) {
				monoTwo = true;
				continue;
			} else {
				break;
			}
		}
		if (!(mono && monoTwo) && (mono || monoTwo)) {

			return true;
		} else {
			return false;
		}

	}

	public static void main(String[] args) {
		int[] arr = { 2, 4, 6, 10, 12 };
		int[] arrTwo = { 2, 4, 6, 10, 8, 12 };
		int[] arrThree = { 5, 3, 2, 1, 3 };
		System.out.println(Monotonic.getMonotonic(arr));
		System.out.println(Monotonic.getMonotonic(arrTwo));
		System.out.println(Monotonic.getMonotonic(arrThree));
	}

}
