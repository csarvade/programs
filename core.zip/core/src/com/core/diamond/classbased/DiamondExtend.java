package com.core.diamond.classbased;

public class DiamondExtend extends DiamondOne, DiamondTwo {
	public void methodOne(){
		System.out.println("Hello India");
	}
public static void main(String args[]){
	DiamondExtend de = new DiamondExtend();
	de.methodOne();
}
}
