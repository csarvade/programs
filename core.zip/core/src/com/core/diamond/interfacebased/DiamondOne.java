package com.core.diamond.interfacebased;

public interface DiamondOne {

	public void methodOne();
}
