package com.core.diamond.interfacebased;

public class DiamondImpl implements DiamondOne, DiamondTwo {

	public void methodOne(){
		System.out.println("HelloWorld");
	}
	
	public static void main(String args[]){
		DiamondImpl di = new DiamondImpl();
		di.methodOne();
	}
	
}
