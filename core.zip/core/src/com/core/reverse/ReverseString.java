package com.core.reverse;

import java.lang.*;
import java.io.*;
import java.util.*;

// Class of ReverseString
class ReverseString {
	public static void main(String[] args) {
		String input = "I Live in India";

		// getBytes() method to convert string into bytes[].
		byte[] strAsByteArray = input.getBytes();// String as byte array using getBytes() method.

		byte[] result = new byte[strAsByteArray.length];// storing String byte array into another byte array until the length limit.

		for (int i = 0; i < strAsByteArray.length; i++)// Store result in reverse order into the result byte[]
			result[i] = strAsByteArray[strAsByteArray.length - i - 1];

		System.out.println(new String(result));
		
	}
}