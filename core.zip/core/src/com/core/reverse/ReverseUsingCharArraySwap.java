package com.core.reverse;

import java.lang.*;
import java.io.*;
import java.util.*;

public class ReverseUsingCharArraySwap {
	// Java program to Reverse a String using swapping of variables

	public static void main(String[] args) {
		String inputString = "Geeks For Geeks";
		char[] charArray = inputString.toCharArray();
		int left, right = 0;
		right = charArray.length - 1;

		for (left = 0; left < right; left++, right--) {
			// Swap values of left and right
			char temp = charArray[left];
			charArray[left] = charArray[right];
			charArray[right] = temp;
		}

		for (char c : charArray)
			System.out.print(c);
		System.out.println();
	}
}
