package com.core.reverse;

import java.util.HashSet;

public class DemoEx {
/*
 * input_string = "abcabcdefggh"
find the longest non repeatative characters in string 
expected Output abcdefg
 */
	public int getLength(char[]ch,String s)
	{
		HashSet set = new HashSet();
		
		for(int i=0;i<ch.length-1;i++) {
			if(ch[i]==ch[i++]) {
				continue;
			}
			
				s = ((String) s).concat(String.valueOf(ch[i]));
				set.add(s);
			
		}
		return set.size();
	}
	public static void main(String [] args) {
		String input_string = "abcabcdefggh";
		char [] ch = input_string.toCharArray();
		String s = "";
		DemoEx demo = new DemoEx();
	System.out.println(	demo.getLength(ch,s));
		
	}
}
