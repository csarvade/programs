package com.core.reverse;

import java.lang.*;
import java.io.*;
import java.util.*;

public class ReverseUsingCharArray {

	public static void main(String[] args) {
		String input = "GeeksFun";

		// convert String to character array
		// by using toCharArray
		char[] charArray = input.toCharArray();

		for (int i = charArray.length - 1; i >= 0; i--) // Higer limit to lower limit
													// looping
			System.out.print(charArray[i]);
	}
}
