package com.core.reverse;

import java.lang.*;
import java.io.*;
import java.util.*;

public class ReverseUsingReverse {
	// Java program to ReverseString using StringBuilder

	public static void main(String[] args) {
		String inputString = "Geeks";

		StringBuilder inputStringBuilder = new StringBuilder();

		// append a string into StringBuilder input1
		inputStringBuilder.append(inputString);

		// reverse StringBuilder input1
		inputStringBuilder = inputStringBuilder.reverse();

		// print reversed String
		for (int i = 0; i < inputStringBuilder.length(); i++)
			System.out.print(inputStringBuilder.charAt(i));
	}

}
