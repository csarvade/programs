package com.core.set.difference;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import javax.swing.text.html.HTMLDocument.Iterator;

public class SetDifference {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Set<String> hsetIs = new HashSet<String>();
	     //add elements to HashSet
		 hsetIs.add("1,2");
		 hsetIs.add("1,2,3");
		 hsetIs.add("1,5");
		 hsetIs.add("1,4");
		 hsetIs.add("1,2,4");
	    Set<String> hset = new HashSet<String>();
	     //add elements to HashSet
	     hset.add("1,2,");
	     hset.add("1,3,1");
	     hset.add("1,2,3");
	     if(hset.removeAll(hsetIs)){
	     for (String temp : hset) {
		        System.out.println("Printing Temp:"+temp);
		     }}
	}

}
