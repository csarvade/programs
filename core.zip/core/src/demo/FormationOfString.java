package demo;

import java.io.DataInputStream;
import java.io.InputStream;
import java.util.Arrays;
import java.util.HashSet;

public class FormationOfString {
public static void main(String []args) {
//	String input = "chetankumarsarvade";
//	String check1 = "sarvadechetankumar"; //true
//	//String check2 = "chetansarvadekumar"; //false
//	//String check3 = "kumarsarvadechetan" //true;
//		int i=0;
//	    int j=0;
//	    int subset = check1.length();
//		while(i<=input.length(); j<=subset;) {
//			j++;
//		}
//		if(j==subset)
//		System.out.println(j);
	
	
	List<Employee> list;
	HashSet<E> s = new HashSet();
	list.stream().map(x->x.id).filter(!s.add(x)).forEach(System.out::println);
	
	
}
}
