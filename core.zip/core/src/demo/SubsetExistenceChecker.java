package demo;

public class SubsetExistenceChecker {

    // Function to check if the subset exists in the input string
    public static boolean isSubsetPresent(String input, String subset) {
        int i = 0; // Pointer for input string
        int j = 0; // Pointer for subset string
        
        // Traverse through the input string
        while (i < input.length() && j < subset.length()) {
            if (input.charAt(i) == subset.charAt(j)) {
                // If characters match, move the pointer for the subset
                j++;
            }
            // Move the pointer for the input string
            i++;
        }
        
        // If we've traversed the entire subset string, it exists in the input string
        return j == subset.length();
    }

    public static void main(String[] args) {
        String input = "abcdef";
        String subset = "ace";

        if (isSubsetPresent(input, subset)) {
            System.out.println("The subset \"" + subset + "\" exists in the input string \"" + input + "\".");
        } else {
            System.out.println("The subset \"" + subset + "\" does not exist in the input string \"" + input + "\".");
        }
    }
}

