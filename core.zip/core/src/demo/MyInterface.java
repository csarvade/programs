package demo;

@FunctionalInterface
public interface MyInterface {
String display(String s);
}


