package demo;

public class SingletonNew {
	public static  SingletonNew instance = null;
	

	private SingletonNew() {} //to defeat with instantication of class
	
	public static synchronized SingletonNew  getConnect() {
		if(instance!=null) {
			return instance;
		}else {
			instance = new SingletonNew();
			return instance;
		}
	}

}
