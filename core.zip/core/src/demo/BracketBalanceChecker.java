package demo;

import java.util.Stack;

import java.util.Stack;

public class BracketBalanceChecker {
    
    // Function to check if the given string has balanced brackets
    public static boolean areBracketsBalanced(String str) {
        // Stack to store opening brackets
        Stack<Character> stack = new Stack<>();
        
        // Traverse through the string
        for (int i = 0; i < str.length(); i++) {
            char ch = str.charAt(i);
            
            // If it's an opening bracket, push it onto the stack
            if (ch == '(' || ch == '{' || ch == '[') {
                stack.push(ch);
            }
            // If it's a closing bracket, check if the stack is empty or mismatched
            else if (ch == ')' || ch == '}' || ch == ']') {
                if (stack.isEmpty()) {
                    return false; // No matching opening bracket
                }
                char openBracket = stack.pop();
                if (!isMatchingPair(openBracket, ch)) {
                    return false; // Mismatched pair
                }
            }
        }
        
        // If the stack is empty, all brackets are matched
        return stack.isEmpty();
    }
    
    // Function to check if the opening and closing brackets match
    private static boolean isMatchingPair(char openBracket, char closeBracket) {
        return (openBracket == '(' && closeBracket == ')') ||
               (openBracket == '{' && closeBracket == '}') ||
               (openBracket == '[' && closeBracket == ']');
    }

    public static void main(String[] args) {
        // Example strings
        String str1 = "{[()]}";
        String str2 = "{[(])}";
        String str3 = "{[}";

        // Test the function
        System.out.println("Is the string \"" + str1 + "\" balanced? " + areBracketsBalanced(str1)); // true
        System.out.println("Is the string \"" + str2 + "\" balanced? " + areBracketsBalanced(str2)); // false
        System.out.println("Is the string \"" + str3 + "\" balanced? " + areBracketsBalanced(str3)); // false
    }
}
