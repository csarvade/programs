package demo;

import java.util.concurrent.BlockingQueue;

public class Producer  extends Thread{

	public void run(BlockingQueue<Producer> queue) {
		for(int i=0;i<100;i++) {
			queue.add(i);
			System.out.println("Using Blocking queue generating elements:"+i);
		}
	}
}
