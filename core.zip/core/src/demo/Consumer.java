package demo;

import java.util.concurrent.BlockingQueue;

public class Consumer extends Thread{
public void run(BlockingQueue<Consumer> queue) {
	for(int j=0;j<100;j++) {
		queue.get(j);
		System.out.println("consumer consuming elements using blocking queue:"+j);
	}
}
}
