package demo;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

public class DemoXabia {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Map<String,List<String>> multiValuedMap = new HashMap<>();
		Map<String,List<String>> multiValuedMapTwo = new HashMap<>();
		multiValuedMap.put("abc", Arrays.asList("pr1","pr2"));
		multiValuedMap.put("abc2", Arrays.asList("pr3","pr2"));
		multiValuedMapTwo.put("abc", Arrays.asList("doc1","doc2"));
		multiValuedMapTwo.put("abc2", Arrays.asList("doc2","doc3"));
		
		String input = "doc1";
		// given value in the list to find key from other map
		HashSet<String> s = new HashMap<>();
		multiValuedMapTwo.entrySet().stream().map(x->x.getKey()).filter(!s.add(x.getValue().contains(input)))).collect();
		
	}
	

}
