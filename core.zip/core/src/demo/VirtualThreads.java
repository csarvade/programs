package demo;
import java.util.*;
public class VirtualThreads {
	public static void main(String[] args) {
		 Thread virtualThread = Thread.ofVirtual().start(() -> {
		    // Code to be executed by the virtual thread
		    
		    for(int i=0;i<1000;i++){
		        System.out.println("Val:"+i);
		    }
		});
		 Thread virtualThreadTwo = Thread.ofVirtual().start(() -> {
		    // Code to be executed by the virtual thread
		    
		    for(int i=0;i<1000;i++){
		        System.out.println("Val:"+i);
		    }
		});
		       
		    }
}
