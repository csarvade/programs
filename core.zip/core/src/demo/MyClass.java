package demo;

public class MyClass {
	public static void main(String []args) {
MyInterface myInterface = (message)->{
	System.out.println("Hello world");
	return message;
};

String s = myInterface.display("Welcome");

String str ="chetan";
}
}
