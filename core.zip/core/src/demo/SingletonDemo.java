package demo;

public class SingletonDemo {
	public static final int SingletonDemo instance =null;
private SingletonDemo() {} //to defeat with instantiation

public static synchronized getConnect() {
	if(instance!=null) {
		return instance;
	}else {
		instance = new SingletonDemo();
		retrun instance;
	}
}
}
