package demo;

import java.sql.Connection;

public class Singleton {
	private  final static final Connection instance=null;
private  Singleton() {} //Defeat with instantiation of object.

public static synchronized getConnection() {
	if(instance!=null) {
		return instance;
	}else {
		//instance = getDBConnection(); //Dao for connection
		return instance;
	}
}
}
