package demo;

import java.util.Arrays;
/******************************************************************************

Online Java Compiler.
Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.List;
import java.util.stream.IntStream;

public class ArrayElements
{
	public static void main(String[] args) {
        int[] number = {1, 9, 8, 4, 0, 0, 2, 7, 0, 6, 0};
        
        // Function call to move zeros to the end
        moveZerosToEnd(number);
        
        // Print the array after moving zeros to the end
//        for (int num : number) {
//            System.out.print(num + " ");
//        }
//        
        
        // alternatively streams
 

        // Stream approach to push zeros to the end
        int[] result = IntStream.concat(
                Arrays.stream(number).filter(n -> n != 0),  // Stream for non-zero elements
                Arrays.stream(number).filter(n -> n == 0)   // Stream for zero elements
        ).toArray();  // Collect the result into an array

        // Printing the result
        System.out.println(Arrays.toString(result));
    }

    public static void moveZerosToEnd(int[] arr) {
        int nonZeroIndex = 0; // To track the index for non-zero elements
        
        // Traverse the array and push non-zero elements to the front
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] != 0) {
                arr[nonZeroIndex] = arr[i];
                nonZeroIndex++;
            }
        }
        
        // Fill the remaining positions with zeroes
        while (nonZeroIndex < arr.length) {
            arr[nonZeroIndex] = 0;
            nonZeroIndex++;
        }
    }


}