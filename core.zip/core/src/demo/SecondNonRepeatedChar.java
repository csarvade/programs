package demo;

import java.util.*;
import java.util.function.*;
import java.util.stream.*;

public class SecondNonRepeatedChar {

    public static Character secondNonRepeatedChar(String str) {
        // Create a map of character frequencies
        Map<Character, Long> frequencyMap = str.chars()
            .mapToObj(c -> (char) c)
            .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

        // Find and return the second non-repeated character
        return str.chars()
            .mapToObj(c -> (char) c)
            .filter(c -> frequencyMap.get(c) == 1) // Filter out repeated characters
            .distinct() // To get characters in order of their first appearance
            .skip(1) // Skip the first non-repeated character
            .findFirst() // Get the second non-repeated character
            .orElse(null); // Return null if no second non-repeated character is found
    }

    public static void main(String[] args) {
        String input = "chetan";
        Character secondNonRepeated = secondNonRepeatedChar(input);
        System.out.println("Second non-repeated character: " + secondNonRepeated);
    }
}

