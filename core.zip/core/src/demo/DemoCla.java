package demo;

import java.util.HashMap;
import java.util.Map;

public class DemoCla {
	public static Map<String,Integer> getCharCount(String s) {
		
		Map<String, Integer> mapChar = new HashMap<String,Integer>();
		for(int i=0;i<s.length();i++) {
			if(mapChar.containsKey(String.valueOf(s.charAt(i)))) {
				mapChar.put(String.valueOf(s.charAt(i)), mapChar.get(i)+1);
			}else {
				mapChar.put(String.valueOf(s.charAt(i)), 1);
			}
		}
		return mapChar;
		
	}
public static void main(String []args) {
	
	
	String s = "aaabbccdeeab";
	
	System.out.println(getCharCount(s));
	
	
	
}
}
