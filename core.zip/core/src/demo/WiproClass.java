package demo;

import java.util.HashMap;


public class WiproClass {


	public static void main(String[] args) {
		// TODO Auto-generated method stub
     HashMap<Integer,String> hm = new HashMap<>();
     hm.put(1, "A");
     hm.put(2, "AB");
     hm.put(3, "ABC");
     
     hm.entrySet().stream().map(x->x.getValue()).filter(x-> x.contentEquals("AB")).reduce((x1,x2) "AB"+"CD").forEach(System.out::println);
	String s= request.getParameter("Str1")? request.getParameter("Str1"):"";
	
	}

}
