package com.core.datastructure;

public class LinkedList {
	Node head;

	class Node {
		int data = 0;
		Node next = null;

		Node(int d) {
			data = d;
			next = null;
		}
	}

	public void printMiddleElement() {
		Node fastPtr = head;
		Node slowPtr = head;
		if (head != null) {
			while (fastPtr != null && fastPtr.next != null) {
				fastPtr = fastPtr.next.next;
				slowPtr = slowPtr.next;
			}
			System.out.println("The Midle Element is:" + slowPtr.data);
		}
	}

	public void push(int newData) {
		Node newNode = new Node(newData);
		newNode.next = head;
		head = newNode;
	}

	public void printList() {
		Node tNode = head;
		while (tNode != null) {
			System.out.println(tNode.data + "->");
			tNode = tNode.next;
		}
		System.out.println("NULL");
	}

	public static void main(String args[]) {
		LinkedList list = new LinkedList();
		for (int i = 5; i > 0; --i) {
			list.push(i);
			list.printList();
			list.printMiddleElement();
		}

	}
}