package com.core.overriding.demo;

public class Overriding {
	public static int add(int a, int b){
	    int sum = 0;
	    sum = a + b;
	    return sum;
		}
	public static void main(String args[]){
		
		
		int s1 = Overriding2.add(2, 3);
	 System.out.println("Overriding example:"+s1);
	}

}