package com.core.overriding.demo;

public class Overriding2 {

	public static int add(int a, int b) {
		int sum = 0;
		int c = 0;
		c = 3;
		sum = a + b + c;
		return sum;
	}

}
