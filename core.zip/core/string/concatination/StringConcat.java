package com.core.string.concatination;

public class StringConcat {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s1 = "Hello";
		System.out.println( "Concating s1+World => HelloWorld == "+s1.concat("World"));// HelloWorld
		String s2 = s1;//Hello only as its just concat
		System.out.println("s2 content = "+s2);
		System.out.println("s1 Intern = "+s1.intern());
	}

}
