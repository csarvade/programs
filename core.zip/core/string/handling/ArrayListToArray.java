package com.core.string.handling;

import java.util.ArrayList;
import java.util.Arrays;

public class ArrayListToArray {

	public static void main(String args[]) {

		// ArrayList containing string objects
		ArrayList<String> aListDays = new ArrayList<String>();
		aListDays.add("Sunday");
		aListDays.add("Monday");
		aListDays.add("Tuesday");
		// First Step: convert ArrayList to an Object array.
		Object[] objDays = aListDays.toArray();
		for(Object obj:objDays){
			System.out.println(obj.toString());
		}
	}
}
