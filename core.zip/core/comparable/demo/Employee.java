package com.core.comparable.demo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

import com.core.comparator.demo.Student;

public class Employee implements Comparable<Employee> {

	private int id;
	private String name;
	private double salary;
	private int age;
	private String address;
	private String email;
	private String mobilenumber;

	public Employee(int id, String name, double salary, int age, String address, String email, String mobilenumber) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.age = age;
		this.address = address;
		this.email = email;
		this.mobilenumber = mobilenumber;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobilenumber() {
		return mobilenumber;
	}

	public void setMobilenumber(String mobilenumber) {
		this.mobilenumber = mobilenumber;
	}

	public int compareTo(Employee emp) {
		// TODO Auto-generated method stub
		return (this.getId() - emp.getId());
	}

	@Override
	public String toString() {
		return "[id=" + this.id + ", name=" + this.name + ", salary=" + this.salary + ", age=" + this.age + ", address="
				+ this.address + ", email=" + this.email + ", mobilenumber=" + this.mobilenumber + "]";
	}

	public static void main(String args[]) {
		ArrayList<Employee> emp = new ArrayList<Employee>();

		emp.add(new Employee(4, "chetan", 83000.00, 32, "madiwala-blr-560068", "csarvade@gmail.com", "9164560113"));
		emp.add(new Employee(2, "kiran", 83000.00, 36, "hubli-dwd-580024", "csarvade@gmail.com", "9902155565"));
		emp.add(new Employee(3, "arun", 83000.00, 34, "hubli-dwd-580024", "csarvade@gmail.com", "9902155564"));
		emp.add(new Employee(5, "suman", 83000.00, 30, "madiwala-blr-560068", "csarvade@gmail.com", "9164560113"));
		emp.add(new Employee(1, "pavan", 83000.00, 38, "madiwala-blr-560068", "csarvade@gmail.com", "9164560113"));
		Collections.sort(emp);
		System.out.println("\nSorted by id");
		for (int i = 0; i < emp.size(); i++) {
			System.out.println(emp.get(i).toString());

		}

	}

}
