package com.core.comparator.demo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Student implements Comparator<Student> {

	public Student(int id, String name, int age) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
	}

	public Student() {
		// TODO Auto-generated constructor stub
	}

	private int id;
	private String name;
	private int age;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public int compare(Student s1, Student s2) {
		// TODO Auto-generated method stub
		return s1.getId() - (s2.getId());
	}

	public static Comparator<Student> ageComparator = new Comparator<Student>() {
		@Override
		public int compare(Student s1, Student s2) {
			return s2.getAge() - s1.getAge();
		}
	};
	public static Comparator<Student> nameComparator = new Comparator<Student>() {
		@Override
		public int compare(Student s1, Student s2) {
			return s2.getName().compareTo(s1.getName());
		}
	};

	public String toString() {
		return "[id=" + this.id + ", name=" + this.name + ", age=" + this.age + "]";
	}

	public static void main(String args[]) {
		ArrayList<Student> s = new ArrayList<Student>();
		s.add(new Student(5, "suman", 30));
		s.add(new Student(1, "pawan", 38));
		s.add(new Student(3, "arun", 34));
		s.add(new Student(2, "kiran", 36));
		s.add(new Student(4, "chetan", 32));

		Collections.sort(s, ageComparator);

		for (int i = 0; i < s.size(); i++) {
			System.out.println("Student Details\n" + s.get(i).toString());
		}
		Collections.sort(s, nameComparator);

		for (int i = 0; i < s.size(); i++) {
			System.out.println("Student Details\n" + s.get(i).toString());
		}
	}

}
