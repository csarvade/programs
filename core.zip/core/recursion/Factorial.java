package com.core.recursion;

public class Factorial {

	public static int fact(int n) {

		if (n < 1) {//pre-condition 1
			return 0;
		} else if (n == 1) { //pre-condition 2
			return 1;
		} else {

			n = n * fact(n - 1); //business logic

		}
		return n;
	}

	public static void main(String args[]) {
		Factorial facto = new Factorial();
		int n = 5;
		System.out.println("Factorial of " + n + " is:=> " + fact(n));
	}
}
