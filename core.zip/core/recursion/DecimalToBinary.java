package com.core.recursion;

public class DecimalToBinary {

	public static int decimalToBinaryConversion(int n){
		int [] bin = new int[100];
		if(n<1){
			return 0;
		}else{
			for(int i=1; i<=n; i++){
			bin[i] = n % 10;
			n = n/2;
			}
		}
		return n;
	}
	public static void main(String args[]){
		DecimalToBinary deciToBin = new DecimalToBinary();
		int n = 1010;
		System.out.println("Decimal to Binary conversion for the number:"+n+" is :"+decimalToBinaryConversion(n));
	}
}
