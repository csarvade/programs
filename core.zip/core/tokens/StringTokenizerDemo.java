package com.core.tokens;

import java.util.*;

public class StringTokenizerDemo {

	public static void main(String[] args) {
		String questions = "what is java?#what are the features of java?#what are oops concepts?#";
		// creating string tokenizer
		StringTokenizer st = new StringTokenizer(questions, "#");

		int temp = 0;
		temp = temp + st.countTokens();
		while (st.hasMoreTokens()) {

			System.out.println("Total tokens :=> " + st.nextToken() + "==="
					+ st.countTokens());

		}
	}
}
