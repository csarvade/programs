package com.core.overloading.demo;

public class Overload {

	public int add(int a, int b){
    int sum = 0;
    sum = a + b;
    return sum;
	}
	public float add(float a, float b){
	    float sum = 0.0f;
	    sum = a + b;
	    return sum;
		}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Overload v = new Overload();
		float f = v.add(0.0f, 0.2f);
		int a = v.add(2, 2);
		
		System.out.println("Float Sum:"+f+"\nInt Sum:"+a);
	}

}