package com.core.diamond.classbased;

public class DiamondTwo {
	public void methodOne(){}
}
