package com.core.diamond.classbased;

public class DiamondOne {
	public void methodOne(){}
}
