package com.core.diamond.interfacebased;

public interface DiamondTwo {

	public void methodOne();
}
